<?php

class FacebookTestCredentials {

  /**
   * These must be filled out with valid Facebook app details for the tests to
   * run.
   */
  public static $appId = '1033351130013312';
  public static $appSecret = '45d781f240672235bc7acc27635ee73c';

}

